<?php
if(!isset($_POST['submit']))
{
	
	echo "error; you need to submit the form!";
}



$name = $_POST['firstName'];
$visitor_email = $_POST['email'];
$message = $_POST['message'];
$option = $_POST['subject'];
$phone = $_POST['phoneNumber'];

$email_subject = "Contact Request from Website	";
$email_body = "You have received a new message from the user : $name.\n". "           ".
	"Phone : $phone"."         ".
	
	" Type : $option". 
	
	"       ";
	
	
$text = $message;
    
$to = "jenifer.3690@gmail.com";

mail($to,$email_subject,$email_body);



$prompt = "Thanks for Contacting us.We will get back to you shortly";
echo "<script type='text/javascript'>
alert('$prompt'); 
location.href='http://kemahflowersandcompany.com';
 </script>";


 require 'class-Clockwork.php';
$key = "f3d983603687f2587fbf774952d2d5214caeec3e";
$options = array( ‘ssl’ => false );

$clockwork = new clockwork($key);

$message = array('to' => "19194910154", 'message'=>$email_body);
$done = $clockwork->send($message);

   
?> 